package com.example.beatfiliveecu

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity\nimport androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var usbManager: UsbManager
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val permissionAction = "com.example.beatfiliveecu.USB_PERMISSION"

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == permissionAction) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted && device != null) openUsbDevice(device)
                else log("USB permission denied")
            }
        }
    }

    private val logLines = mutableStateListOf<String>()
    private var connected by mutableStateOf(false)
    private var deviceLabel by mutableStateOf("No USB device")
    private var baudRate by mutableStateOf("10400")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        ContextCompat.registerReceiver(this, receiver, IntentFilter(permissionAction), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            MaterialTheme {
                Dashboard(
                    connected = connected,
                    deviceLabel = deviceLabel,
                    logs = logLines.toList(),
                    baudRate = baudRate,
                    onBaudChange = { baudRate = it },
                    onConnect = { connectUsb() },
                    onDisconnect = { disconnectUsb() },
                    onSend = { sendHex(it) },
                    onClear = { logLines.clear() }
                )
            }
        }
        log("App started. Connect FTDI/K-Line interface via USB OTG.")
    }

    private fun connectUsb() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            log("No USB serial device found. Check OTG, cable, and FTDI.")
            return
        }
        val driver = drivers.first()
        val device = driver.device
        deviceLabel = "USB ${device.vendorId}:${device.productId}"
        if (!usbManager.hasPermission(device)) {
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(permissionAction),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            usbManager.requestPermission(device, pi)
        } else {
            openUsbDevice(device)
        }
    }

    private fun openUsbDevice(device: UsbDevice) {
        try {
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IllegalStateException("Unsupported USB serial device")
            val connection = usbManager.openDevice(device)
                ?: throw IllegalStateException("Could not open USB device")
            val serialPort = driver.ports.first()
            serialPort.open(connection)
            serialPort.setParameters(
                baudRate.toIntOrNull() ?: 10400,
                8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE
            )
            port = serialPort
            connected = true
            log("Serial connected. Baud=${baudRate}, 8N1.")
            ioManager = SerialInputOutputManager(serialPort, object : SerialInputOutputManager.Listener {
                override fun onNewData(data: ByteArray) {
                    val hex = data.joinToString(" ") { "%02X".format(it) }
                    runOnUiThread { log("RX: $hex") }
                }
                override fun onRunError(e: Exception) {
                    runOnUiThread { log("Serial error: ${e.message}") }
                }
            }).also { executor.submit(it) }
        } catch (e: Exception) {
            log("Connect error: ${e.message}")
            disconnectUsb()
        }
    }

    private fun sendHex(text: String) {
        val serialPort = port ?: run { log("Not connected"); return }
        try {
            val bytes = text.trim().split(Regex("\\s+"))
                .filter { it.isNotBlank() }
                .map { it.toInt(16).toByte() }.toByteArray()
            serialPort.write(bytes, 1000)
            log("TX: ${bytes.joinToString(" ") { "%02X".format(it) }}")
        } catch (e: Exception) {
            log("TX error: ${e.message}")
        }
    }

    private fun disconnectUsb() {
        try { ioManager?.stop() } catch (_: Exception) {}
        ioManager = null
        try { port?.close() } catch (_: Exception) {}
        port = null
        connected = false
        log("Disconnected")
    }

    private fun log(message: String) {
        logLines.add(message)
        if (logLines.size > 250) logLines.removeAt(0)
    }

    override fun onDestroy() {
        disconnectUsb()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun Dashboard(
    connected: Boolean,
    deviceLabel: String,
    logs: List<String>,
    baudRate: String,
    onBaudChange: (String) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSend: (String) -> Unit,
    onClear: () -> Unit
) {
    var tx by remember { mutableStateOf("01 00") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("BEAT FI LIVE ECU", style = MaterialTheme.typography.headlineSmall)
        Text("FTDI USB Serial • K-Line prototype")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (connected) "CONNECTED" else "DISCONNECTED", style = MaterialTheme.typography.titleMedium)
                Text(deviceLabel)
                OutlinedTextField(
                    value = baudRate, onValueChange = onBaudChange,
                    label = { Text("Baud rate (prototype)") }, singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onConnect, enabled = !connected) { Text("Connect USB") }
                    OutlinedButton(onClick = onDisconnect, enabled = connected) { Text("Disconnect") }
                }
            }
        }
        Text("Raw Serial Terminal", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = tx, onValueChange = { tx = it },
                label = { Text("HEX bytes") }, modifier = Modifier.weight(1f)
            )
            Button(onClick = { onSend(tx) }, enabled = connected) { Text("Send") }
        }
        Row {
            Text("Log", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onClear) { Text("Clear") }
        }
        LazyColumn(Modifier.fillMaxSize(), reverseLayout = true) {
            items(logs.reversed()) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
