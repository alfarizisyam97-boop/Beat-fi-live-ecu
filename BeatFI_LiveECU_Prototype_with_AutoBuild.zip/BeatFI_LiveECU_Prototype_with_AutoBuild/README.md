# Beat FI Live ECU Prototype

Android starter app for USB serial testing with FTDI adapters.

## Included
- USB host permission flow
- USB serial detection via usb-serial-for-android
- Connect/disconnect
- Configurable baud rate (default 10400 is placeholder)
- Raw HEX TX and RX logging
- GitHub Actions workflow to build a debug APK

## Build APK automatically
1. Create a GitHub repository and upload this project.
2. Push the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Run **Build Android APK** (or wait for push build).
5. Open the successful workflow run and download the `BeatFI-LiveECU-debug` artifact.
6. Extract the artifact and install the APK on Android. Allow installation from your file manager if Android asks.

## Build locally
Open in Android Studio and sync Gradle, then run `gradle assembleDebug` or use Build > Build APK.

## Important protocol/hardware note
This is a serial-terminal scaffold, not a verified Honda ECU reader. It does NOT initialize a Honda ECU or decode live data yet. FTDI USB serial must connect to a suitable K-Line interface/transceiver; do not connect FTDI UART pins directly to motorcycle K-Line. Exact ECU part number, initialization sequence, baud rate, request frames, and checksum must be verified. The circuit in the reference image is not electrically validated.
